#!/bin/sh

sudo -k;

_exec=$@

export MAIN_DIALOG='
<window title="Password" resizable="true" icon-name="emerzo">
    <vbox>
        <hbox>
            <frame>
                <text>
                    <label>Enter the password</label>
                </text>
            </frame>
        </hbox>
        <hbox>
            <entry activates-default="true">
                <variable>password</variable>
                <visible>password</visible>
            </entry>
        </hbox>
        <hbox>
            <button>
                <label>Cancel</label>
            </button>
            <button can-default="true" has-default="true" use-stock="true">
                <label>Ok</label>
            </button>
        </hbox>
    </vbox>
</window>
'

out=`gtkdialog --program=MAIN_DIALOG`
eval $out

if ! echo "$password" | grep -Pq '^$'; then
    if ! echo "$password" | sudo -S $_exec; then
        notify-send "Password incorrect";
    fi    
fi
