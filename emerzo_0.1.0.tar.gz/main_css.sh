#!/bin/sh

. /emerzo/var.sh

echo -en '
<window title="Emerzo" resizable="true" width-request="768" height-request="512" xalign="3" icon-name="emerzo">
    <notebook tab-labels="Update | Install | Search | Settings|">
        <vbox>
            <hbox>
                <button label="Start">
                    <action>/emerzo/launcher.sh "update" "$RUN_SYNC" "$U_PRETEND" "$SKIP_UPDATE"</action>
                </button>
                <button label="Stop"><action>/emerzo/quit.sh "update"</action></button>
            </hbox>
            <hbox>
                <button label="Clear"><action>/emerzo/clear.sh "update"</action></button>
            </hbox>
            <hbox><button label="Exit"></button></hbox>
            <hbox>
                <frame>
                    <checkbox>
                        <variable>RUN_SYNC</variable>
                        <label>Run sync</label>
                    </checkbox>
                    <checkbox>
                        <variable>SKIP_UPDATE</variable>
                        <label>Skip update</label>
                    </checkbox>
                    <checkbox>
                        <variable>U_PRETEND</variable>
                        <label>Pretend</label>
                    </checkbox>
                </frame>
            </hbox>
            <hbox>
                <text>
                    <label>Count of the displayed lines</label>
                </text>
                <spinbutton>
                    <variable>COUNT_LINES_UPDATE</variable>
                    <default>'$UPDATE_COUNT_LINES'</default>
                </spinbutton>
                <button>
                    <action>/emerzo/count_lines.sh "update" "$COUNT_LINES_UPDATE"</action>
                    <label>Ok</label>
                </button>
            </hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit auto-refresh="true" editable="false" cursor-visible="false">
                        <input file>'$DISPLAY_UPDATE_LOG'</input>
                    </edit>
                </frame>
            </hbox>
        </vbox>
        <vbox>
            <hbox>
                <entry><variable>_INSTALL</variable></entry>
                <button label="Install">
                    <action>/emerzo/launcher.sh "install" $_INSTALL $I_PRETEND</action>
                </button>
                <button label="Stop"><action>/emerzo/quit.sh "install"</action></button>
                <button label="Clear"><action>/emerzo/clear.sh "install"</action></button>
            </hbox>
            <hbox>
                <frame>
                    <checkbox>
                        <variable>I_PRETEND</variable>
                        <label>Pretend</label>
                    </checkbox>
                </frame>
            </hbox>
            <hbox>
                <text>
                    <label>Count of the displayed lines</label>
                </text>
                <spinbutton>
                    <variable>COUNT_LINES_INSTALL</variable>
                    <default>'$INSTALL_COUNT_LINES'</default>
                </spinbutton>
                <button>
                    <action>/emerzo/count_lines.sh "install" "$COUNT_LINES_INSTALL"</action>
                    <label>Ok</label>
                </button>
            </hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit editable="false" cursor-visible="false"
                          file-monitor="true" auto-refresh="true">
                        <input file>'$DISPLAY_INSTALL_LOG'</input>
                    </edit>
                </frame>
            </hbox>
        </vbox>
        <vbox>
            <hbox>
                <entry><variable>SEARCH</variable></entry>
                <button label="Search">
                    <action>/emerzo/launcher.sh "search" $SEARCH</action>
                </button>
                <button label="Stop"><action>/emerzo/quit.sh "search"</action></button>
                <button label="Clear"><action>/emerzo/clear.sh "search"</action></button>
            </hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit auto-refresh="true" editable="false" cursor-visible="false">
                        <input file>'$DISPLAY_SEARCH_LOG'</input>
                    </edit>
                </frame>
            </hbox>
        </vbox>
        <vbox>
            <vbox scrollable="true">
                <frame Update settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_UPDATE_LOG</variable>
                        <default>'$REDIRECTION_UPDATE_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_UPDATE_LOG</variable>
                        <default>'$DISPLAY_UPDATE_LOG'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Install settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_INSTALL_LOG</variable>
                        <default>'$REDIRECTION_INSTALL_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_INSTALL_LOG</variable>
                        <default>'$DISPLAY_INSTALL_LOG'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Install settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_SEARCH_LOG</variable>
                        <default>'$REDIRECTION_SEARCH_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_SEARCH_LOG</variable>
                        <default>'$DISPLAY_SEARCH_LOG'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Status execute of Sync>
                    <entry>
                    <variable>SYNC_STATUS</variable>
                    <default>'$SYNC_STATUS'</default>
                    </entry>
                </frame>
                <frame Last sync time file (unix)>
                    <entry>
                    <variable>LAST_SYNC</variable>
                    <default>'$time_file'</default>
                    </entry>
                </frame>
                <frame Count of the displayed lines (Update)>
                    <entry>
                    <variable>UPDATE_COUNT_LINES</variable>
                    <default>'$UPDATE_COUNT_LINES'</default>
                    </entry>
                </frame>
                <frame Count of the displayed lines (Install)>
                    <entry>
                    <variable>INSTALL_COUNT_LINES</variable>
                    <default>'$INSTALL_COUNT_LINES'</default>
                    </entry>
                </frame>
                <frame Log Reverse Regexp>
                    <entry>
                    <variable>LR_REGEXP</variable>
                    <default>'$LR_REGEXP'</default>
                    </entry>
                </frame>
                <frame Log Reverse Interval>
                    <entry>
                    <variable>LR_INTERVAL</variable>
                    <default>'$LR_INTERVAL'</default>
                    </entry>
                </frame>
            </vbox>
            <hbox>
                <button label="Restore"><action>/emerzo/default_settings.sh</action></button>
                <button label="Save">
                    <action>/emerzo/save_settings.sh "$REDIRECTION_UPDATE_LOG" "$DISPLAY_UPDATE_LOG" "$REDIRECTION_INSTALL_LOG" "$DISPLAY_INSTALL_LOG" "$REDIRECTION_SEARCH_LOG" "$DISPLAY_SEARCH_LOG" "$SYNC_STATUS" "$LAST_SYNC" "$UPDATE_COUNT_LINES" "$INSTALL_COUNT_LINES" "$LR_REGEXP" "$LR_INTERVAL"</action>
                </button>
            </hbox>
        </vbox>
    </notebook>
</window>';
