#!/bin/sh

. /emerzo/var.sh

if [[ "$1" == "update" ]] || [[ "$1" == "sync" ]]; then # only update [ and/or sync ] stop
    stop_msg="$(echo -en ">>> Update: stop\n$(cat $DISPLAY_UPDATE_LOG)\n")";
    echo "$stop_msg" > "$DISPLAY_UPDATE_LOG";
    screen -X -S emerzo_sync quit;
    screen -X -S emerzo_update quit;
    screen -X -S emerzo_lr_update quit;
elif [[ "$1" == "install" ]]; then # only install stop
    stop_msg="$(echo -en ">>> Install: stop\n$(cat $DISPLAY_INSTALL_LOG)\n")";
    echo "$stop_msg" > "$DISPLAY_INSTALL_LOG";
    screen -X -S emerzo_install quit;
    screen -X -S emerzo_lr_install quit;
elif [[ "$1" == "search" ]]; then # only search stop
    stop_msg="$(echo -en ">>> Search: stop\n$(cat $DISPLAY_SEARCH_LOG)\n")";
    echo "$stop_msg" > "$DISPLAY_SEARCH_LOG";
    screen -X -S emerzo_search quit;
    screen -X -S emerzo_lr_search quit;
else # everything stop
    $0 "update";
    $0 "install";
    $0 "search";
fi

