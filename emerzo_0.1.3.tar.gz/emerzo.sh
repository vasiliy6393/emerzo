#!/bin/sh

# All functions (update, merging, etc) are performed in the Screen session.
# For this reason, crutches have to be used in some places.
# I thought for a long time how best to do and came to the fact 
# that this is the best solution for me

# Author: Vasiliy Pogoreliy
# Email for suggestions and bug reports: vasiliy.6393@gmail.com
# My native language is Russian, but I can use the translator.
# Please don't use slang.

function default_settings(){
NEW_SETTINGS="REDIRECTION_UPDATE_LOG=\"/tmp/emerzo/redirection_update.log\";
DISPLAY_UPDATE_LOG=\"/tmp/emerzo/display_update.log\";
UPDATE_STATUS_BAR=\"/tmp/emerzo/update_status_bar.log\";
REDIRECTION_MERGING_LOG=\"/tmp/emerzo/redirection_merging.log\";
DISPLAY_MERGING_LOG=\"/tmp/emerzo/display_merging.log\";
MERGING_STATUS_BAR=\"/tmp/emerzo/merging_status_bar.log\";
REDIRECTION_UNMERGE_LOG=\"/tmp/emerzo/redirection_unmerge.log\";
DISPLAY_UNMERGE_LOG=\"/tmp/emerzo/display_unmerge.log\";
REDIRECTION_SEARCH_LOG=\"/tmp/emerzo/redirection_search.log\";
DISPLAY_SEARCH_LOG=\"/tmp/emerzo/display_search.log\";
SYNC_STATUS=\"/tmp/emerzo/sync.status\";
LAST_SYNC=\"/root/emerzo/last_sync.time\";
UPDATE_COUNT_LINES=\"7\";
MERGING_COUNT_LINES=\"7\";
UNMERGE_COUNT_LINES=\"7\";
LR_REGEXP=\"Calculating dependencies|^>>> |^ \*|\[ebuild|WARNING:\";
LR_INTERVAL=\"0.2\";
";
if [[ "$1" == "create" ]]; then
    echo "$NEW_SETTINGS" > /etc/emerzo.conf;
else
    mv /etc/emerzo.conf /etc/emerzo.conf.rest;
    echo "$NEW_SETTINGS" > /etc/emerzo.conf;
    msg="Some changes will take effect after the program is restarted.";
    zenity --title="Emerzo Save Settings" --width="300" --info --text="$msg";
fi
}

function gsudo(){
    title="Emerzo";
    cmd="$0 \"main_root\"";
    export MAIN_DIALOG='
    <window title="'$title'" resizable="true" icon-name="emerzo">
        <vbox>
            <hbox>
                <frame>
                    <text>
                        <label>Enter the password</label>
                    </text>
                </frame>
            </hbox>
            <hbox>
                <entry activates-default="true">
                    <variable>password</variable>
                    <visible>password</visible>
                </entry>
            </hbox>
            <hbox>
                <button>
                    <label>Cancel</label>
                </button>
                <button can-default="true" has-default="true" use-stock="true">
                    <label>Ok</label>
                </button>
            </hbox>
        </vbox>
    </window>
    '
    out=`gtkdialog --program=MAIN_DIALOG`
    eval $out
    if ! echo "$password" | grep -Pq '^$'; then
      echo "$password" | sudo -S sh -c "[[ ! -e '/etc/emerzo.conf' ]] && $0 \"default_settings\" \"create\"; $cmd";
    fi
}

[[ -e "/etc/emerzo.conf" ]] && . /etc/emerzo.conf;

function update(){
    echo "" > "$UPDATE_STATUS_BAR";
    echo -en "\n\n" > $REDIRECTION_UPDATE_LOG;
    echo "false" > "$SYNC_STATUS";
    if echo "$2" | grep -Pq 'true'; then screen -d -m -S emerzo_sync $0 "sync";
    else echo "true" > "$SYNC_STATUS";
    fi
    if echo "$4" | grep -Pq 'true'; then # if user skip update
        while ! $(cat "$SYNC_STATUS"); do sleep 1; done # wait sync.sh
        echo ">>> Update: skip" >> $REDIRECTION_UPDATE_LOG;
    else
        if echo "$3" | grep -Pq 'true'; then PRETEND=" --pretend"; else PRETEND=""; fi
        while ! $(cat "$SYNC_STATUS"); do sleep 1; done # wait sync.sh
        echo ">>> Update$PRETEND: start" >> $REDIRECTION_UPDATE_LOG;
        echo -en "\n\n" >> $REDIRECTION_UPDATE_LOG;
        emerge $PRETEND --update --deep @world >> $REDIRECTION_UPDATE_LOG;
        echo ">>> Update: done" >> $REDIRECTION_UPDATE_LOG;
    fi
    sleep 1;

    if echo "$5" | grep -Pq 'true'; then # check kernel
        echo ">>> Update: checking for a new kernel" >> $REDIRECTION_UPDATE_LOG;
        KRNL_VER_REP="$(emerge --search gentoo-source | grep -P 'Latest version')";
        KERNEL_VER_INSTALLED="$(echo "$KRNL_VER_REP" | grep -P 'installed' | awk '{print $4}')";
        KERNEL_VER_ESELECT="$(eselect kernel list | awk -F\- '{print $2}' | grep -Pv '^$')";
        
        if [[ "a$KERNEL_VER_INSTALLED" == "a$KERNEL_VER_ESELECT" ]]; then
            echo ">>> Update: latest kernel" >> $REDIRECTION_UPDATE_LOG;
        else
            echo ">>> Update: new kernel" >> $REDIRECTION_UPDATE_LOG;
        fi
    fi

    sleep 1;
    screen -X -S emerzo_lr_update quit;
    echo "" > "$UPDATE_STATUS_BAR";
}

function merging(){
    echo "" > "$MERGING_STATUS_BAR";
    if echo "$3" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi
    echo ">>> merging $PRETEND $2: start" > "$REDIRECTION_MERGING_LOG";
    emerge $PRETEND $2 >> "$REDIRECTION_MERGING_LOG";
    s="$(echo -en ">>> merging $2: done\n$(cat "$DISPLAY_MERGING_LOG")\n")";
    echo "$s" > "$DISPLAY_MERGING_LOG";
    sleep 1;
    screen -X -S emerzo_lr_merging quit;
    echo "" > "$MERGING_STATUS_BAR";
}

function unmerge(){
    if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi
    echo ">>> unmerging $PRETEND $1: start" > "$REDIRECTION_UNMERGE_LOG";
    emerge $PRETEND --unmerge $1 >> "$REDIRECTION_UNMERGE_LOG";
    if echo "$3" | grep -Pq 'true'; then
        echo ">>> depclean $PRETEND: start" >> "$REDIRECTION_UNMERGE_LOG";
        emerge $PRETEND --depclean >> "$REDIRECTION_UNMERGE_LOG";
    fi
    s="$(echo -en ">>> unmerging $1: done\n$(cat "$DISPLAY_UNMERGE_LOG")\n")";
    echo "$s" > "$DISPLAY_UNMERGE_LOG";
    screen -X -S emerzo_lr_unmerge quit;
}

function search(){
    echo "Search for $1" > "$DISPLAY_SEARCH_LOG";
    emerge --search $1 | tr '\b' ' ' > "$DISPLAY_SEARCH_LOG.tmp";
    cat "$DISPLAY_SEARCH_LOG.tmp" > "$DISPLAY_SEARCH_LOG";
    rm -f "$DISPLAY_SEARCH_LOG.tmp";
}

function clear_log(){
    if ! screen -list | grep -Pq "emerzo_$1"; then # if it is not execute
        echo "" > $REDIRECTION_UPDATE_LOG; echo "" > $DISPLAY_UPDATE_LOG;
        case "$1" in
          "update" ) echo "" > "$UPDATE_STATUS_BAR";;
          "merging" ) echo "" > "$MERGING_STATUS_BAR";;
        esac
    fi
}

function count_lines(){
    echo "$2" > /tmp/emerzo/count_lines_$1.cnt;
    echo -en " " >> /tmp/emerzo/display_$1.log;
    sed -i "1 i >>> Count of the displayed lines used: $2" /tmp/emerzo/display_$1.log;
}

function save_settings(){
NEW_SETTINGS="REDIRECTION_UPDATE_LOG=\"$1\";
DISPLAY_UPDATE_LOG=\"$2\";
UPDATE_STATUS_BAR=\"$3\";
REDIRECTION_MERGING_LOG=\"$4\";
DISPLAY_MERGING_LOG=\"$5\";
MERGING_STATUS_BAR=\"$6\";
REDIRECTION_UNMERGE_LOG=\"$7\";
DISPLAY_UNMERGE_LOG=\"$8\";
REDIRECTION_SEARCH_LOG=\"$9\";
DISPLAY_SEARCH_LOG=\"${10}\";
SYNC_STATUS=\"${11}\";
LAST_SYNC=\"${12}\";
UPDATE_COUNT_LINES=\"${13}\";
MERGING_COUNT_LINES=\"${14}\";
UNMERGE_COUNT_LINES=\"${15}\";
LR_REGEXP=\"${16}\";
LR_INTERVAL=\"${17}\";
";

if mv /etc/emerzo.conf /etc/emerzo.conf.bak; then
    echo "$NEW_SETTINGS" > /etc/emerzo.conf;
    msg="Some changes will take effect after the program is restarted.";
    zenity --title="Emerzo Save Settings" --width="300" --info --text="$msg";
fi
}

function launch(){
    if ! screen -list | grep -Pq "emerzo_$1"; then
        screen -d -m -S emerzo_$1 $0 "screen_$1" $1 $2 $3 $4 $5;
        if [[ "$1" != "search" ]]; then
            screen -d -m -S emerzo_lr_$1 $0 "screen_lr_$1" "$1";
        fi
    fi
}

function launcher(){ launch $1 $2 $3 $4 $5; }

function lr(){
    if [[ "$1" == "update" ]]; then
        redirection_log="$REDIRECTION_UPDATE_LOG";
        display_log="$DISPLAY_UPDATE_LOG";
        count_lines_file="/tmp/emerzo/count_lines_update.cnt";
        STATUS_BAR="$UPDATE_STATUS_BAR";
    elif [[ "$1" == "merging" ]]; then
        redirection_log="$REDIRECTION_MERGING_LOG";
        display_log="$DISPLAY_MERGING_LOG";
        count_lines_file="/tmp/emerzo/count_lines_merging.cnt";
        STATUS_BAR="$MERGING_STATUS_BAR";
    elif [[ "$1" == "unmerge" ]]; then
        redirection_log="$REDIRECTION_UNMERGE_LOG";
        display_log="$DISPLAY_UNMERGE_LOG";
        count_lines_file="/tmp/emerzo/count_lines_unmerge.cnt";
    else
        exit;
    fi
    
    while true; do
        if [[ -e "$count_lines_file" ]] && grep -Pq '^[0-9]+$' "$count_lines_file"; then
            count_lines="$(cat "$count_lines_file")";
        else
            count_lines="7";
        fi
        log_data="$(tac "$redirection_log" | grep -P "$LR_REGEXP" |
                                             head -n $count_lines | tr -d '\b')";
        log_file="$(cat "$display_log" | tr -d '\b')";
        if [[ "$log_data" != "$log_file" ]]; then
            echo "$log_data" > $display_log;
            echo "$log_data" | grep -P '>>> Emerging|>>> Install' | head -n1 > $STATUS_BAR;
        fi
        sleep $LR_INTERVAL;
    done
}

function main_css(){
echo -en '
<window title="Emerzo" resizable="true" width-request="768" height-request="512" xalign="3" icon-name="emerzo">
    <notebook tab-labels="Update | Merging | Unmerge (with deps) | Search | Settings|">
        <vbox>
            <hbox>
                <button label="Start">
                    <action>'$0' "update" "$RUN_SYNC" "$U_PRETEND" "$SKIP_UPDATE" "$CHECK_KERNEL"</action>
                </button>
                <button label="Stop"><action>'$0' "stop_update"</action></button>
            </hbox>
            <hbox>
                <button label="Clear"><action>'$0' "clear_update"</action></button>
            </hbox>
            <hbox><button label="Exit"></button></hbox>
            <hbox>
                <frame>
                    <checkbox>
                        <variable>RUN_SYNC</variable>
                        <label>Run sync</label>
                    </checkbox>
                    <checkbox>
                        <variable>SKIP_UPDATE</variable>
                        <label>Skip update</label>
                    </checkbox>
                    <checkbox>
                        <variable>U_PRETEND</variable>
                        <label>Pretend (Update)</label>
                    </checkbox>
                    <checkbox>
                        <variable>CHECK_KERNEL</variable>
                        <label>Check for kernel update requirement</label>
                    </checkbox>
                </frame>
            </hbox>
            <hbox>
                <text>
                    <label>Count of the displayed lines</label>
                </text>
                <spinbutton>
                    <variable>COUNT_LINES_UPDATE</variable>
                    <default>'$UPDATE_COUNT_LINES'</default>
                </spinbutton>
                <button>
                    <action>'$0' "cl_update" "$COUNT_LINES_UPDATE"</action>
                    <label>Ok</label>
                </button>
            </hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit auto-refresh="true" editable="false" cursor-visible="true">
                        <input file>'$DISPLAY_UPDATE_LOG'</input>
                    </edit>
                </frame>
            </hbox>
            <hbox>
                <entry file-monitor="true" auto-refresh="true">
                    <input file>'$UPDATE_STATUS_BAR'</input>
                </entry>
            </hbox>
        </vbox>
        <vbox>
            <hbox>
                <entry><variable>MERGING</variable></entry>
                <button label="Merging">
                    <action>'$0' "merging" "$MERGING" "$M_PRETEND"</action>
                </button>
                <button label="Stop"><action>'$0' "stop_merging"</action></button>
                <button label="Clear"><action>'$0' "clear_merging"</action></button>
            </hbox>
            <hbox><button label="Exit"></button></hbox>
            <hbox>
                <frame>
                    <checkbox>
                        <variable>M_PRETEND</variable>
                        <label>Pretend</label>
                    </checkbox>
                </frame>
            </hbox>
            <hbox>
                <text>
                    <label>Count of the displayed lines</label>
                </text>
                <spinbutton>
                    <variable>COUNT_LINES_MERGING</variable>
                    <default>'$MERGING_COUNT_LINES'</default>
                </spinbutton>
                <button>
                    <action>'$0' "cl_merging" "$COUNT_LINES_MERGING"</action>
                    <label>Ok</label>
                </button>
            </hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit editable="false" cursor-visible="true"
                          file-monitor="true" auto-refresh="true">
                        <input file>'$DISPLAY_MERGING_LOG'</input>
                    </edit>
                </frame>
            </hbox>
            <hbox>
                <entry file-monitor="true" auto-refresh="true">
                    <input file>'$MERGING_STATUS_BAR'</input>
                </entry>
            </hbox>
        </vbox>
        <vbox>
            <hbox>
                <entry><variable>_UNMERGE</variable></entry>
                <button label="Unmerge">
                    <action>'$0' "unmerge" "$_UNMERGE" "$UM_PRETEND" "$UM_DEPCLEAN"</action>
                </button>
                <button label="Stop"><action>'$0' "stop_unmerge"</action></button>
                <button label="Clear"><action>'$0' "clear_unmerge"</action></button>
            </hbox>
            <hbox><button label="Exit"></button></hbox>
            <hbox>
                <frame>
                    <checkbox>
                        <variable>UM_PRETEND</variable>
                        <label>Pretend</label>
                    </checkbox>
                    <checkbox>
                        <variable>UM_DEPCLEAN</variable>
                        <label>Depclean</label>
                    </checkbox>
                </frame>
            </hbox>
            <hbox>
                <text>
                    <label>Count of the displayed lines</label>
                </text>
                <spinbutton>
                    <variable>COUNT_LINES_UNMERGE</variable>
                    <default>'$UNMERGE_COUNT_LINES'</default>
                </spinbutton>
                <button>
                    <action>'$0' "cl_unmerge" "$COUNT_LINES_UNMERGE"</action>
                    <label>Ok</label>
                </button>
            </hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit editable="false" cursor-visible="true"
                          file-monitor="true" auto-refresh="true">
                        <input file>'$DISPLAY_UNMERGE_LOG'</input>
                    </edit>
                </frame>
            </hbox>
        </vbox>
        <vbox>
            <hbox>
                <entry><variable>SEARCH</variable></entry>
                <button label="Search">
                    <action>'$0' "search" "$SEARCH"</action>
                </button>
                <button label="Stop"><action>'$0' "stop_search"</action></button>
                <button label="Clear"><action>'$0' "clear_search"</action></button>
            </hbox>
            <hbox><button label="Exit"></button></hbox>
            <hbox space-fill="true" space-expand="true" scrollable="true">
                <frame>
                    <edit auto-refresh="true" editable="false" cursor-visible="true">
                        <input file>'$DISPLAY_SEARCH_LOG'</input>
                    </edit>
                </frame>
            </hbox>
        </vbox>
        <vbox>
            <vbox scrollable="true">
                <frame Update settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_UPDATE_LOG</variable>
                        <default>'$REDIRECTION_UPDATE_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_UPDATE_LOG</variable>
                        <default>'$DISPLAY_UPDATE_LOG'</default>
                        </entry>
                    </frame>
                    <frame Status bar>
                        <entry>
                        <variable>UPDATE_STATUS_BAR</variable>
                        <default>'$UPDATE_STATUS_BAR'</default>
                        </entry>
                    </frame>
                    <frame Count of the displayed lines>
                        <entry>
                        <variable>UPDATE_COUNT_LINES</variable>
                        <default>'$UPDATE_COUNT_LINES'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Sync settings>
                    <frame Status execute of Sync>
                        <entry>
                        <variable>SYNC_STATUS</variable>
                        <default>'$SYNC_STATUS'</default>
                        </entry>
                    </frame>
                    <frame Last sync time file (unix)>
                        <entry>
                        <variable>LAST_SYNC</variable>
                        <default>'$LAST_SYNC'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Merging settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_MERGING_LOG</variable>
                        <default>'$REDIRECTION_MERGING_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_MERGING_LOG</variable>
                        <default>'$DISPLAY_MERGING_LOG'</default>
                        </entry>
                    </frame>
                    <frame Status bar>
                        <entry>
                        <variable>MERGING_STATUS_BAR</variable>
                        <default>'$MERGING_STATUS_BAR'</default>
                        </entry>
                    </frame>
                    <frame Count of the displayed lines>
                        <entry>
                        <variable>MERGING_COUNT_LINES</variable>
                        <default>'$MERGING_COUNT_LINES'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Unmerge settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_UNMERGE_LOG</variable>
                        <default>'$REDIRECTION_UNMERGE_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_UNMERGE_LOG</variable>
                        <default>'$DISPLAY_UNMERGE_LOG'</default>
                        </entry>
                    </frame>
                    <frame Count of the displayed lines>
                        <entry>
                        <variable>UNMERGE_COUNT_LINES</variable>
                        <default>'$UNMERGE_COUNT_LINES'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Search settings>
                    <frame Redirection>
                        <entry>
                        <variable>REDIRECTION_SEARCH_LOG</variable>
                        <default>'$REDIRECTION_SEARCH_LOG'</default>
                        </entry>
                    </frame>
                    <frame Display>
                        <entry>
                        <variable>DISPLAY_SEARCH_LOG</variable>
                        <default>'$DISPLAY_SEARCH_LOG'</default>
                        </entry>
                    </frame>
                </frame>
                <frame Log Reverse Regexp>
                    <entry>
                    <variable>LR_REGEXP</variable>
                    <default>'$LR_REGEXP'</default>
                    </entry>
                </frame>
                <frame Log Reverse Interval>
                    <entry>
                    <variable>LR_INTERVAL</variable>
                    <default>'$LR_INTERVAL'</default>
                    </entry>
                </frame>
            </vbox>
            <hbox>
                <button label="Restore"><action>'$0' "default_settings"</action></button>
                <button label="Save">
                    <action>'$0' "save_settings" "$REDIRECTION_UPDATE_LOG" "$DISPLAY_UPDATE_LOG" "$UPDATE_STATUS_BAR" "$REDIRECTION_MERGING_LOG" "$DISPLAY_MERGING_LOG" "$MERGING_STATUS_BAR" "$REDIRECTION_UNMERGE_LOG" "$DISPLAY_UNMERGE_LOG" "$REDIRECTION_SEARCH_LOG" "$DISPLAY_SEARCH_LOG" "$SYNC_STATUS" "$LAST_SYNC" "$UPDATE_COUNT_LINES" "$MERGING_COUNT_LINES" "$UNMERGE_COUNT_LINES" "$LR_REGEXP" "$LR_INTERVAL"</action>
                </button>
                <button label="Exit"></button>
            </hbox>
        </vbox>
    </notebook>
</window>';
}

function ctrl_q(){
while true; do
if xprop -id $(DISPLAY=":0.0" xprop -root | grep "_NET_ACTIVE_WINDOW(WINDOW)" | awk '{print $5}' | sed 's/,$//' | grep -P '^0x') | grep -Pq 'Emerzo'; then

# This script is not mine. I took it on the Internet and edited it
xinput test-xi2 --root | perl -lne "
    BEGIN{$\"=\",\";
        while (<X>) {\$k{\$1}=\$2 if /^keycode\s+(\d+) = (\w+)/}
        while (<X>) {if (/^(\w+)\s+(\w*)/){(\$k=\$2)=~s/_[LR]$//;\$m[\$i++]=\$k||\$1}}
        close X;
    }
    if (/^EVENT type.*\((.*)\)/) {\$e = \$1}
    elsif (/detail: (\d+)/) {\$d=\$1}
    elsif (/modifiers:.*effective: (.*)/) {
        \$m=\$1;
        if (\$e =~ /^Key/){
            my @mods;
            for (0..\$#m) {push @mods, \$m[\$_] if (hex(\$m) & (1<<\$_))}
            if( \"\$e\" == \"KeyPress\" and \"\$d\" == \"24\" and \"\$m\" == \"0x4\" ){
                system ('sleep 0.2; kill $(ps aux | grep -Pi "gtkdialog" | grep -P 'MAIN_DIALOG' |
                                                    awk '{print $2}')');
            }
        }
    }"
fi
done
}

function main_root(){
    if id -u | grep -Pq '^0$'; then
        mkdir -p /tmp/emerzo/;
        screen -d -m -S emerzo_ctrl_q $0 "ctrl_q";
        # creating temporary files
        touch "$DISPLAY_UPDATE_LOG" "$DISPLAY_MERGING_LOG" "$DISPLAY_UNMERGE_LOG" \
              "$DISPLAY_SEARCH_LOG" "$DISPLAY_MERGING_NOW" "$UPDATE_STATUS_BAR" \
              "$MERGING_STATUS_BAR";
        GTKDIALOG=gtkdialog
        export MAIN_DIALOG=$(main_css);
        case $1 in
            -d | --dump) echo "$MAIN_DIALOG" ;;
            *) $GTKDIALOG --program=MAIN_DIALOG --center ;;
        esac
        # if something is started, it will be killed
        $0 "stop_update"; $0 "stop_merging"; $0 "stop_unmerge"; $0 "stop_search"; $0 "stop_ctrl_q";
        rm -f /tmp/emerzo/*; # clear logs
    else
        echo "You must be root";
    fi
}

function main(){ id -u | grep -Pq '^0$' && $0 "main_root" || gsudo; }

function _stop(){
    if [[ "$1" == "update" ]] || [[ "$1" == "sync" ]]; then # only update [ and/or sync ] stop
        stop_msg="$(echo -en ">>> Update: stop\n$(cat $DISPLAY_UPDATE_LOG)\n")";
        screen -X -S emerzo_sync quit;
        screen -X -S emerzo_update quit;
        screen -X -S emerzo_lr_update quit;
        echo "$stop_msg" > "$DISPLAY_UPDATE_LOG";
        echo "" > "$UPDATE_STATUS_BAR";
    elif [[ "$1" == "merging" ]]; then # only merging stop
        stop_msg="$(echo -en ">>> Merging: stop\n$(cat $DISPLAY_MERGING_LOG)\n")";
        screen -X -S emerzo_merging quit;
        screen -X -S emerzo_lr_merging quit;
        echo "$stop_msg" > "$DISPLAY_MERGING_LOG";
        echo "" > "$MERGING_STATUS_BAR";
    elif [[ "$1" == "unmerge" ]]; then # only unmerge stop
        stop_msg="$(echo -en ">>> Unmerge: stop\n$(cat $DISPLAY_UNMERGE_LOG)\n")";
        screen -X -S emerzo_unmerge quit;
        screen -X -S emerzo_lr_unmerge quit;
        echo "$stop_msg" > "$DISPLAY_UNMERGE_LOG";
    elif [[ "$1" == "search" ]]; then # only search stop
        stop_msg="$(echo -en ">>> Search: stop\n$(cat $DISPLAY_SEARCH_LOG)\n")";
        screen -X -S emerzo_search quit;
        screen -X -S emerzo_lr_search quit;
        echo "$stop_msg" > "$DISPLAY_SEARCH_LOG";
    elif [[ "$1" == "ctrl_q" ]]; then # only ctrl_q stop
        screen -X -S emerzo_ctrl_q quit;
    fi
}

# BLOCK FUNCTIONS FOR SYNC

function last_sync_dif(){
    LAST_SYNC="$1";
    [[ ! -e "$LAST_SYNC" ]] && date +%s > $LAST_SYNC;
    time_now="$(date +%s)";
    last_sync="$(grep -Po '^\d+$' $LAST_SYNC)";
    last_sync_dif=$((86400-($time_now-$last_sync)));
    echo $last_sync_dif;
}

function emerge_sync(){
    LAST_SYNC="$1";
    REDIRECTION_UPDATE_LOG="$2";
    echo ">>> emerge sync" >> $REDIRECTION_UPDATE_LOG;
    if emerge --sync >> $REDIRECTION_UPDATE_LOG; then
        echo ">>> emerge --sync: done" >> $REDIRECTION_UPDATE_LOG;
        date +%s > $LAST_SYNC;
    else
        echo ">>> Sync error" >> $REDIRECTION_UPDATE_LOG;
    fi
}

function skip_sync(){
    REDIRECTION_UPDATE_LOG=$2;
    last_sync_dif="$(echo "$1" | grep -Po '^\d+$')";
    time_wait_mins="$((($last_sync_dif/60)%60))";
    time_wait_hours="$(($last_sync_dif/60/60))";
    [[ $time_wait_hours -gt 1 ]] && hs="s" || hs="";
    [[ $time_wait_mins -gt 1 ]] && ms="s" || ms="";
    MSG_1=">>> Please wait to emerge sync";
    MSG_2="$time_wait_hours hour$hs";
    MSG_3="$time_wait_mins minute$ms";
    echo "$MSG_1 $MSG_2 $MSG_3" >> $REDIRECTION_UPDATE_LOG;
}

function sync(){
    if ! id -u | grep -Pq '^0$'; then
        echo ">>> Emerge sync: permission denied" >> $REDIRECTION_UPDATE_LOG;
    else
        mkdir -p "/root/emerzo";
        echo "false" > $SYNC_STATUS;
        RUN_SYNC='false';
        if echo $* | grep -Pq 'run\-sync=true'; then
            RUN_SYNC='true';
        fi
        if [[ "$RUN_SYNC" == "true" ]]; then # if the user wants to run emerge --sync
            if [[ ! -e "$LAST_SYNC" ]]; then # if the user did not execute emerge --sync
                emerge_sync $LAST_SYNC $REDIRECTION_UPDATE_LOG;
            else
                last_sync_dif=$(last_sync_dif "$LAST_SYNC");
                if [[ "$last_sync_dif" -lt "0" ]]; then # if last emerge --sync is great 24 hours
                    emerge_sync $LAST_SYNC $REDIRECTION_UPDATE_LOG;
                else
                    skip_sync $last_sync_dif $REDIRECTION_UPDATE_LOG;
                fi
            fi
        fi
        echo "true" > $SYNC_STATUS;
    fi
}

# END BLOCK FUNCTIONS FOR SYNC

case "$1" in
    "gsudo"             ) gsudo;;
    "main_root"         ) main_root;;
    "ctrl_q"            ) ctrl_q;;
    "sync"              ) sync "run-sync=true";;
    "update"            ) launcher "$1" "$2" "$3" "$4" "$5";;
    "merging"           ) launcher "$1" "$2" "$3" "$4";;
    "unmerge"           ) launcher "$1" "$2" "$3" "$4";;
    "search"            ) launcher "$1" "$2" "$3";;
    "screen_update"     ) update "$2" "$3" "$4" "$5" $6;;
    "screen_merging"    ) merging "$2" "$3" "$4" "$5";;
    "screen_unmerge"    ) unmerge "$3" "$4" "$5";;
    "screen_search"     ) search "$3";;
    "screen_lr_update"  ) lr "update";;
    "screen_lr_merging" ) lr "merging";;
    "screen_lr_unmerge" ) lr "unmerge";;
    "clear_update"      ) clear_log "update";;
    "clear_merging"     ) clear_log "merging";;
    "clear_unmerge"     ) clear_log "unmerge";;
    "clear_search"      ) clear_log "search";;
    "cl_update"         ) count_lines "update" "$2";;
    "cl_merging"        ) count_lines "merging" "$2";;
    "cl_unmerge"        ) count_lines "unmerge" "$2";;
    "default_settings"  ) default_settings "$2";;
    "save_settings"     ) save_settings "${2}" "${3}" "${4}" "${5}" "${6}" "${7}" "${8}" "${9}" \
                                        "${10}" "${11}" "${12}" "${13}" "${14}" "${15}" "${16}" \
                                        "${17}" "${18}" "${19}";;
    "stop_update"       ) _stop "update";;
    "stop_merging"      ) _stop "merging";;
    "stop_unmerge"      ) _stop "unmerge";;
    "stop_search"       ) _stop "search";;
    "stop_ctrl_q"       ) _stop "ctrl_q";;
    *                   ) main "$2";;
esac

