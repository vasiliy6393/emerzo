#!/bin/bash

GSUDO="/emerzo/gsudo.sh";
SCREEN_NAME="$1";
CMD="$2";
if id -u | grep -Pq '^0$'; then
    /emerzo/main_root.sh $1;
else
    $GSUDO /emerzo/main_root.sh $1;
fi

