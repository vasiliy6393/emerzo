#!/bin/sh

if [[ "$1" == "update" ]]; then
    if ! screen -list | grep -Pq 'world_update'; then
        screen -d -m -S update /emerzo/update.sh $2 $3;
        screen -d -m -S lr /emerzo/lr.sh "update";
    fi
elif [[ "$1" == "install" ]]; then
    if ! screen -list | grep -Pq 'install'; then
        screen -d -m -S install /emerzo/install.sh $2 $3;
        screen -d -m -S lr /emerzo/lr.sh "install";
    fi
elif [[ "$1" == "search" ]]; then
    screen -d -m -S search /emerzo/search.sh $2;
fi


