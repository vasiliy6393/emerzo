#!/bin/sh
echo "Please wait" > /tmp/emerzo/search.txt;
emerge --search $1 | grep -Pv '^....$' >> /tmp/emerzo/search.txt;
