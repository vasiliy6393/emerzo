#!/bin/sh

if [[ "$1" == "update" ]] || [[ "$1" == "sync" ]]; then # only update [ and/or sync ] stop
    PID_1="$(ps aux | grep -P '\/bin\/sh \/emerzo\/lr\.sh update' | awk '{print $2}')";
    PID_2="$(ps aux | grep -P '\/bin\/sh \/emerzo\/sync\.sh' | awk '{print $2}')";
    PID_3="$(ps aux | grep -P '\/bin\/sh \/emerzo\/update\.sh' | awk '{print $2}')";
elif [[ "$1" == "install" ]]; then # only install stop
    PID_1="$(ps aux | grep -P '\/bin\/sh \/emerzo\/lr\.sh install' | awk '{print $2}')";
    PID_4="$(ps aux | grep -P '\/bin\/sh \/emerzo\/install\.sh' | awk '{print $2}')";
elif [[ "$1" == "search" ]]; then # only search stop
    PID_5="$(ps aux | grep -P '\/bin\/sh \/emerzo\/search\.sh' | awk '{print $2}')";
else # everything stop
    PID_1="$(ps aux | grep -P '\/bin\/sh \/emerzo\/lr\.sh' | awk '{print $2}')";
    PID_2="$(ps aux | grep -P '\/bin\/sh \/emerzo\/sync\.sh' | awk '{print $2}')";
    PID_3="$(ps aux | grep -P '\/bin\/sh \/emerzo\/update\.sh' | awk '{print $2}')";
    PID_4="$(ps aux | grep -P '\/bin\/sh \/emerzo\/install\.sh' | awk '{print $2}')";
    PID_5="$(ps aux | grep -P '\/bin\/sh \/emerzo\/search\.sh' | awk '{print $2}')";
fi

for i in $PID_1 $PID_2 $PID_3 $PID_4 $PID_5; do # to spit if it's wrong =)
    kill -9 $i > /dev/null 2>&1;
    rm -f /tmp/emerzo/*; # clear logs
done
