#!/bin/sh

if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi

echo "" | tee "/tmp/emerzo/install.log";
echo -en ">>> merging $1\n\n" | tee -a "/tmp/emerzo/install.log";
emerge $PRETEND $1 2>&1 | grep -Pv '^....$' | tee -a "/tmp/emerzo/install.log";
echo ">>> merging $1: done" | tee -a "/tmp/emerzo/install.log";

PID_INSTALL="$(ps aux | grep -P '\/bin\/sh /emerzo/lr\.sh install' | awk '{print $2}')";
if ! echo "$PID_INSTALL" | grep -Pq '^$'; then kill -9 $PID_INSTALL; fi
