#!/bin/sh

exit;

if id -u | grep -Pq '^0$'; then
    echo "" > /tmp/emerzo/update_rev.log;
    echo "" > /tmp/emerzo/install_rev.log;
    echo "" > /tmp/emerzo/search.txt;
fi
