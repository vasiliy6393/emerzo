#!/bin/sh

echo "false" > "/tmp/emerzo/sync.status";
if echo "$1" | grep -Pq 'true'; then screen -d -m -S sync /emerzo/sync.sh run-sync=$1;
else echo "true" > "/tmp/emerzo/sync.status";
fi

if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi

while ! $(cat "/tmp/emerzo/sync.status"); do sleep 1; done
echo -en ">>> update world: start\n\n" | tee -a /tmp/emerzo/update.log;
emerge $PRETEND --update --deep @world | tee -a /tmp/emerzo/update.log;
echo -en ">>> update world: done\n\n" | tee -a /tmp/emerzo/update.log;

sleep 2;

PID_UPDATE="$(ps aux | grep -P '\/bin\/sh \/emerzo\/lr\.sh update' | awk '{print $2}')";
if ! echo "$PID_UPDATE" | grep -Pq '^$'; then kill -9 $PID_UPDATE; fi
