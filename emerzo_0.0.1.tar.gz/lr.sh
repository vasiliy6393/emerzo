#!/bin/sh

sleep 1;

if [[ "$1" == "update" ]]; then
    log="/tmp/emerzo/update.log";
    log_rev="/tmp/emerzo/update_rev.log";
elif [[ "$1" == "install" ]]; then
    log="/tmp/emerzo/install.log";
    log_rev="/tmp/emerzo/install_rev.log";
fi

while true; do
    log_data="$(tac "$log" | grep -P 'Calculating dependencies|^>>> |^ \*|\[ebuild')";
    log_file="$(cat "$log_rev")";
    if [[ "$log_data" != "$log_file" ]]; then
        echo "$log_data" | tee $log_rev;
    fi
    sleep 1
done
