#!/bin/sh

sleep 0.2;

if [[ "$1" == "update" ]]; then
    redirection_log="/tmp/emerzo/redirection_update.log";
    display_log="/tmp/emerzo/display_update.log";
    count_lines="/tmp/emerzo/count_lines_update.cnt";
elif [[ "$1" == "install" ]]; then
    redirection_log="/tmp/emerzo/redirection_install.log";
    display_log="/tmp/emerzo/display_install.log";
    count_lines_file="/tmp/emerzo/count_lines_install.cnt";
elif [[ "$1" == "search" ]]; then
    exit;
    # redirection_log="/tmp/emerzo/redirection_search.log";
    # display_log="/tmp/emerzo/display_search.log";
    # count_lines_file="/tmp/emerzo/count_lines_search.cnt";
fi

LR_REGEXP="Calculating dependencies|^>>> |^ \*|\[ebuild";
LR_INTERVAL="0.2";

while true; do
    if [[ -e "$count_lines_file" ]] && grep -Pq '^[0-9]+$' "$count_lines_file"; then
        count_lines="$(cat "$count_lines_file")";
    else
        count_lines="7";
    fi

    log_data="$(tac "$redirection_log" | grep -P "$LR_REGEXP" | head -n $count_lines)";
    log_file="$(cat "$display_log")";
    [[ "$log_data" != "$log_file" ]] && echo "$log_data" > $display_log;
    sleep $LR_INTERVAL;
done
