#!/bin/sh
echo "Please wait" >> /tmp/emerzo/display_search.log;
emerge --search $1 | grep -Pv '^....$' >> /tmp/emerzo/display_search.log;
