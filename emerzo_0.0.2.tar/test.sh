#! /bin/bash

export MAIN_DIALOG='
<window title="Password" resizable="true">
    <vbox>
        <hbox>
            <text><label>Count of the displayed lines</label></text>
            <spinbutton activates-default="true">
                <variable>COUNT_LINES</variable><default>7</default>
            </spinbutton>
            <button can-default="true" has-default="true" use-stock="true">
                <action>echo "$COUNT_LINES" > "/tmp/emerzo/count_lines_update.cnt"</action>
                <label>Ok</label>
            </button>
        </hbox>
    </vbox>
</window>
'

gtkdialog --program=MAIN_DIALOG;

