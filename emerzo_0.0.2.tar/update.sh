#!/bin/sh

echo -en "\n\n" > /tmp/emerzo/redirection_update.log;

echo "false" > "/tmp/emerzo/sync.status";
if echo "$1" | grep -Pq 'true'; then screen -d -m -S sync /emerzo/sync.sh run-sync=$1;
else echo "true" > "/tmp/emerzo/sync.status";
fi

if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi

while ! $(cat "/tmp/emerzo/sync.status"); do sleep 1; done # wait sync.sh
echo ">>> Update: start" >> /tmp/emerzo/redirection_update.log;
echo -en "\n\n" >> /tmp/emerzo/redirection_update.log;
emerge $PRETEND --update --deep @world >> /tmp/emerzo/redirection_update.log;
echo ">>> Update: done" >> /tmp/emerzo/redirection_update.log;

sleep 1;

PID_LR_UPDATE="$(ps aux | grep -P '\/bin\/sh \/emerzo\/lr\.sh update' | awk '{print $2}')";
if ! echo "$PID_LR_UPDATE" | grep -Pq '^$'; then kill -9 $PID_LR_UPDATE; fi
