#!/bin/sh

echo "$2" > /tmp/emerzo/count_lines_$1.cnt;
echo -en " " >> /tmp/emerzo/display_$1.log;
sed -i "1 i >>> Count of the displayed lines used: $2" /tmp/emerzo/display_$1.log;
