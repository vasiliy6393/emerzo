#!/bin/sh

GSUDO="/emerzo/gsudo.sh";
if id -u | grep -Pq '^0$'; then
    /emerzo/main_root.sh $1;
else
    $GSUDO /emerzo/main_root.sh $1;
fi

