#!/bin/sh

NEW_SETTINGS="REDIRECTION_UPDATE_LOG=\"$1\";
DISPLAY_UPDATE_LOG=\"$2\";
REDIRECTION_INSTALL_LOG=\"$3\";
DISPLAY_INSTALL_LOG=\"$4\";
REDIRECTION_SEARCH_LOG=\"$5\";
DISPLAY_SEARCH_LOG=\"$6\";
SYNC_STATUS="$7";
time_file=\"$8\";
UPDATE_COUNT_LINES=\"$9\";
INSTALL_COUNT_LINES=\"${10}\";
LR_REGEXP=\"${11}\";
LR_INTERVAL=\"${12}\";
";

if mv /emerzo/var.sh /emerzo/var.sh.bak; then
    echo "$NEW_SETTINGS" > /emerzo/var.sh;
    msg="Some changes will take effect after the program is restarted.";
    zenity --title="Emerzo Save Settings" --width="300" --info --text="$msg";
fi
