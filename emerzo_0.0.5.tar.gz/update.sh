#!/bin/sh

. /emerzo/var.sh

echo -en "\n\n" > $REDIRECTION_UPDATE_LOG;

echo "false" > "$SYNC_STATUS";
if echo "$1" | grep -Pq 'true'; then screen -d -m -S emerzo_sync /emerzo/sync.sh run-sync=$1;
else echo "true" > "$SYNC_STATUS";
fi

if [[ "$3" == "true" ]]; then # if user skip update
    while ! $(cat "$SYNC_STATUS"); do sleep 1; done # wait sync.sh
    echo ">>> Update: skip" >> $REDIRECTION_UPDATE_LOG;
else
    if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi
    while ! $(cat "$SYNC_STATUS"); do sleep 1; done # wait sync.sh
    echo ">>> Update: start" >> $REDIRECTION_UPDATE_LOG;
    echo -en "\n\n" >> $REDIRECTION_UPDATE_LOG;
    emerge $PRETEND --update --deep @world >> $REDIRECTION_UPDATE_LOG;
    echo ">>> Update: done" >> $REDIRECTION_UPDATE_LOG;
fi

sleep 1;
screen -X -S emerzo_lr_update quit;
