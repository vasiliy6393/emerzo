#!/bin/sh

sleep 0.2;

. /emerzo/var.sh

if [[ "$1" == "update" ]]; then
    redirection_log="$REDIRECTION_UPDATE_LOG";
    display_log="$DISPLAY_UPDATE_LOG";
    count_lines_file="/tmp/emerzo/count_lines_update.cnt";
elif [[ "$1" == "install" ]]; then
    redirection_log="$REDIRECTION_INSTALL_LOG";
    display_log="$DISPLAY_INSTALL_LOG";
    count_lines_file="$COUNT_LINES";
else
    exit;
fi

while true; do
    if [[ -e "$count_lines_file" ]] && grep -Pq '^[0-9]+$' "$count_lines_file"; then
        count_lines="$(cat "$count_lines_file")";
    else
        count_lines="7";
    fi
    log_data="$(tac "$redirection_log" | grep -P "$LR_REGEXP" | head -n $count_lines)";
    log_file="$(cat "$display_log")";
    [[ "$log_data" != "$log_file" ]] && echo "$log_data" > $display_log;
    sleep $LR_INTERVAL;
done

