#!/bin/sh

. /emerzo/var.sh

function clear_log(){
    if ! screen -list | grep -Pq "emerzo_$1"; then
        echo "" > $2; echo "" > $3;
    fi
}

case "$1" in
    "update" ) clear_log "update" "$REDIRECTION_UPDATE_LOG" "$DISPLAY_UPDATE_LOG";;
    "install" ) clear_log "install" "$REDIRECTION_INSTALL_LOG" "$DISPLAY_INSTALL_LOG";;
    "search" ) clear_log "search" "$REDIRECTION_SEARCH_LOG" "$DISPLAY_SEARCH_LOG";;
esac

