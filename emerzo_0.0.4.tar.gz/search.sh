#!/bin/sh

. /emerzo/var.sh

echo "Please wait" >> $DISPLAY_SEARCH_LOG;
emerge --search $1 | grep -Pv '^....$' >> $DISPLAY_SEARCH_LOG;
