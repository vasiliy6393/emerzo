#!/bin/sh

function launch(){
    if ! screen -list | grep -Pq "emerzo_$1"; then
        screen -d -m -S emerzo_$1 /emerzo/$1.sh $2 $3;
        screen -d -m -S emerzo_lr_$1 /emerzo/lr.sh "$1";
    fi
}

launch $1 $2 $3;

