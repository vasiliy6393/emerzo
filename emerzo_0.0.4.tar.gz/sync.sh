#!/bin/sh

. /emerzo/var.sh

function time_dif(){
    time_file="$1";
    [[ ! -e "$time_file" ]] && date +%s > $time_file;
    time_now="$(date +%s)";
    time_fl="$(grep -Po '^\d+$' $time_file)";
    time_dif=$((86400-($time_now-$time_fl)));
    echo $time_dif;
}

function emerge_sync(){
    time_file="$1";
    REDIRECTION_UPDATE_LOG="$2";
    echo ">>> emerge sync" >> $REDIRECTION_UPDATE_LOG;
    if emerge --sync >> $REDIRECTION_UPDATE_LOG; then
        echo ">>> emerge --sync: done" >> $REDIRECTION_UPDATE_LOG;
        date +%s > $time_file;
    else
        echo ">>> Sync error" >> $REDIRECTION_UPDATE_LOG;
    fi
}

function skip_sync(){
    REDIRECTION_UPDATE_LOG=$2;
    time_dif="$(echo "$1" | grep -Po '^\d+$')";
    time_wait_mins="$((($time_dif/60)%60))";
    time_wait_hours="$(($time_dif/60/60))";
    [[ $time_wait_hours -gt 1 ]] && hs="s" || hs="";
    [[ $time_wait_mins -gt 1 ]] && ms="s" || ms="";
    MSG_1=">>> Please wait to emerge sync";
    MSG_2="$time_wait_hours hour$hs";
    MSG_3="$time_wait_mins minute$ms";
    echo "$MSG_1 $MSG_2 $MSG_3" >> $REDIRECTION_UPDATE_LOG;
}

mkdir -p "$HOME/emerzo";

if ! id -u | grep -Pq '^0$'; then
    echo ">>> Emerge sync: permission denied" >> $REDIRECTION_UPDATE_LOG;
else
    echo "false" > $SYNC_STATUS;
    RUN_SYNC='false';
    if echo $* | grep -Pq 'run\-sync=true'; then
        RUN_SYNC='true';
    fi

    if [[ "$RUN_SYNC" == "true" ]]; then # if the user wants to run emerge --sync
        if [[ ! -e "$time_file" ]]; then # if the user did not execute emerge --sync
            emerge_sync $time_file $REDIRECTION_UPDATE_LOG;
        else
            time_dif=$(time_dif "$time_file");
            if [[ "$time_dif" -lt "0" ]]; then # if last emerge --sync is great 24 hours
                emerge_sync $time_file $REDIRECTION_UPDATE_LOG;
            else
                skip_sync $time_dif $REDIRECTION_UPDATE_LOG;
            fi
        fi
    fi
    echo "true" > $SYNC_STATUS;
fi

