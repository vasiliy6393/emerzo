#!/bin/sh

. /emerzo/var.sh

if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi

echo ">>> merging $1" > "$REDIRECTION_INSTALL_LOG";
emerge $PRETEND $1 >> "$REDIRECTION_INSTALL_LOG";
s="$(echo -en ">>> Install $1: done\n$(cat "$DISPLAY_INSTALL_LOG")\n")";
echo "$s" > "$DISPLAY_INSTALL_LOG";

screen -X -S emerzo_lr_install quit;
