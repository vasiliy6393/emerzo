REDIRECTION_UPDATE_LOG="/tmp/emerzo/redirection_update.log";
DISPLAY_UPDATE_LOG="/tmp/emerzo/display_update.log";
REDIRECTION_INSTALL_LOG="/tmp/emerzo/redirection_install.log";
DISPLAY_INSTALL_LOG="/tmp/emerzo/display_install.log";
REDIRECTION_SEARCH_LOG="/tmp/emerzo/redirection_search.log";
DISPLAY_SEARCH_LOG="/tmp/emerzo/display_search.log";

SYNC_STATUS="/tmp/emerzo/sync.status";
time_file="$HOME/emerzo/last_sync.time";
