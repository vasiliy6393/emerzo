#!/bin/sh

if echo "$2" | grep -Pq 'true'; then PRETEND="--pretend"; else PRETEND=""; fi

echo ">>> merging $1" > "/tmp/emerzo/redirection_install.log";
emerge $PRETEND $1 >> "/tmp/emerzo/redirection_install.log";
s="$(echo -en ">>> Install $1: done\n$(cat "/tmp/emerzo/display_install.log")\n")";
echo "$s" > "/tmp/emerzo/display_install.log";


PID_LR_INSTALL="$(ps aux | grep -P '\/bin\/sh /emerzo/lr\.sh install' | awk '{print $2}')";
if ! echo "$PID_LR_INSTALL" | grep -Pq '^$'; then kill -9 $PID_LR_INSTALL; fi
