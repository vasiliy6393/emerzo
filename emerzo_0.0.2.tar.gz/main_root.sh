#!/bin/sh

if id -u | grep -Pq '^0$'; then
    mkdir -p /tmp/emerzo/;
    touch /tmp/emerzo/display_update.log;
    touch /tmp/emerzo/display_install.log;
    touch /tmp/emerzo/display_search.log;
    GTKDIALOG=gtkdialog
    export MAIN_DIALOG="$(cat "/emerzo/main.css")"
    case $1 in
        -d | --dump) echo "$MAIN_DIALOG" ;;
        *) $GTKDIALOG --program=MAIN_DIALOG --center ;;
    esac
    /emerzo/quit.sh;
    rm -f /tmp/emerzo/*; # clear logs
fi
