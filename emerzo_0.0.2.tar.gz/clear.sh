#!/bin/sh

function clear_log(){
    if ! ps aux | grep -Pq "\/bin\/sh \/emerzo\/$1\.sh"; then
        echo "" > /tmp/emerzo/redirection_$1.log; echo "" > /tmp/emerzo/display_$1.log;
    fi
}

case "$1" in
    "update" ) clear_log "update";;
    "install" ) clear_log "install";;
    "search" ) clear_log "search";;
esac

